@echo off
@ echo.  
@ echo.      ITAsset4deloy部署程序，请按   任意键   继续
@ echo.
pause
set "CURDIR=%~dp0"
if "%CURDIR:~-1%"=="\" set "CURDIR=%CURDIR:~0,-1%"
set path=%path%;%CURDIR%
start /b /wait cmd /c "lsrunase /user:murphy.wang.ad /password:2Vp9n9Y596GL2PDhHoA= /domain:macn.group /command:"ITAsset4deloy.bat" /runpath:%CURDIR%" & exit /b 0