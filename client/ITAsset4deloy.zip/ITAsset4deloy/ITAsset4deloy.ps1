﻿# ================================================
#  ITAsset4 部署脚本
#  需要以【管理员身份】运行 PowerShell
# ================================================
#Requires -RunAsAdministrator

$ErrorActionPreference = "Stop"

$targetDir  = "C:\ProgramData\ITAsset4"
$sourceDir  = "\\172.29.147.120\agacdfs\Public\IT\90soft\ITAsset4"
$startupDir = "C:\ProgramData\Microsoft\Windows\Start Menu\Programs\StartUp"
$keepFile   = "config.ini"
$serviceExe = "ITAsset4.Service.exe"
$trayLnk    = "ITAsset4.Tray.lnk"

Write-Host "================================================" -ForegroundColor Yellow
Write-Host "  ITAsset4 部署脚本" -ForegroundColor Yellow
Write-Host "================================================" -ForegroundColor Yellow


# ── 步骤 0：停止服务与进程 ────────────────────────────────
Write-Host "`n[0/4] 停止相关服务与进程 ..." -ForegroundColor Cyan

# 停止 Windows 服务（若存在，带超时）
$svcName = "ITAsset4agent"
$svcTimeout = 10   # 等待秒数，超时后强制 kill

$svc = Get-Service -Name $svcName -ErrorAction SilentlyContinue
if ($svc) {
    if ($svc.Status -ne 'Stopped') {
        $svc.Stop()
        try {
            $svc.WaitForStatus('Stopped', [TimeSpan]::FromSeconds($svcTimeout))
            Write-Host "  [OK] 服务已停止：$svcName" -ForegroundColor Green
        } catch {
            Write-Host "  [警告] 服务 $svcTimeout 秒内未停止，强制终止进程..." -ForegroundColor DarkYellow
            $svcProc = Get-WmiObject Win32_Service -Filter "Name='$svcName'" -ErrorAction SilentlyContinue
            if ($svcProc -and $svcProc.ProcessId -gt 0) {
                Stop-Process -Id $svcProc.ProcessId -Force -ErrorAction SilentlyContinue
                Write-Host "  [OK] 进程已强制终止 (PID: $($svcProc.ProcessId))" -ForegroundColor Green
            }
        }
    } else {
        Write-Host "  [跳过] 服务已处于停止状态：$svcName" -ForegroundColor DarkGray
    }
} else {
    Write-Host "  [跳过] 服务不存在：$svcName" -ForegroundColor DarkGray
}

# 强制结束进程
foreach ($procName in @("ITAsset4.Tray", "ITAsset4.Service")) {
    $procs = Get-Process -Name $procName -ErrorAction SilentlyContinue
    if ($procs) {
        $procs | Stop-Process -Force
        Write-Host "  [OK] 进程已终止：$procName" -ForegroundColor Green
    } else {
        Write-Host "  [跳过] 进程未运行：$procName" -ForegroundColor DarkGray
    }
}

Start-Sleep -Seconds 2   # 等待进程完全释放文件锁


# ── 步骤 1：清理目录，保留 config.ini ─────────────────────
Write-Host "`n[1/4] 清理目录，保留 $keepFile ..." -ForegroundColor Cyan

if (-not (Test-Path $targetDir)) {
    New-Item -ItemType Directory -Path $targetDir -Force | Out-Null
    Write-Host "  [OK] 目录不存在，已自动创建：$targetDir" -ForegroundColor Green
} else {
    Get-ChildItem -Path $targetDir -File | Where-Object { $_.Name -ne $keepFile } | ForEach-Object {
        Remove-Item -Path $_.FullName -Force
        Write-Host "    删除文件：$($_.Name)"
    }
    Get-ChildItem -Path $targetDir -Directory | ForEach-Object {
        Remove-Item -Path $_.FullName -Recurse -Force
        Write-Host "    删除目录：$($_.Name)"
    }
    Write-Host "  [OK] 清理完成（已保留 $keepFile）" -ForegroundColor Green
}


# ── 步骤 2：从网络共享拷贝所有文件 ───────────────────────
Write-Host "`n[2/4] 从 $sourceDir 拷贝文件 ..." -ForegroundColor Cyan

if (-not (Test-Path $sourceDir)) {
    Write-Host "  [错误] 无法访问源路径：$sourceDir" -ForegroundColor Red
    exit 1
}

Copy-Item -Path "$sourceDir\*" -Destination $targetDir -Recurse -Force
Write-Host "  [OK] 拷贝完成" -ForegroundColor Green


# ── 步骤 3：安装 Windows 服务 ──────────────────────────────
Write-Host "`n[3/4] 执行服务安装命令 ($serviceExe --install) ..." -ForegroundColor Cyan

$exePath = Join-Path $targetDir $serviceExe
if (-not (Test-Path $exePath)) {
    Write-Host "  [错误] 未找到可执行文件：$exePath" -ForegroundColor Red
    exit 1
}

$proc = Start-Process -FilePath $exePath `
    -ArgumentList "--install" `
    -WorkingDirectory $targetDir `
    -Wait -PassThru -NoNewWindow

if ($proc.ExitCode -ne 0) {
    Write-Host "  [错误] $serviceExe --install 返回退出码：$($proc.ExitCode)" -ForegroundColor Red
    exit 1
}
Write-Host "  [OK] 服务安装成功（退出码 0）" -ForegroundColor Green


# ── 步骤 4：添加开机启动快捷方式 ──────────────────────────
Write-Host "`n[4/4] 复制 $trayLnk 到开机启动目录 ..." -ForegroundColor Cyan

$lnkSource = Join-Path $targetDir $trayLnk
if (-not (Test-Path $lnkSource)) {
    Write-Host "  [错误] 未找到快捷方式文件：$lnkSource" -ForegroundColor Red
    exit 1
}

if (-not (Test-Path $startupDir)) {
    New-Item -ItemType Directory -Path $startupDir -Force | Out-Null
}

Copy-Item -Path $lnkSource -Destination $startupDir -Force
Write-Host "  [OK] 快捷方式已复制到：$startupDir" -ForegroundColor Green


Write-Host "`n================================================" -ForegroundColor Yellow
Write-Host "  部署全部完成！" -ForegroundColor Yellow
Write-Host "================================================`n" -ForegroundColor Yellow