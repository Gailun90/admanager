@echo off
set "CURDIR=%~dp0"
if "%CURDIR:~-1%"=="\" set "CURDIR=%CURDIR:~0,-1%"
set path=%path%;%CURDIR%
powershell -ExecutionPolicy Bypass -File "%CURDIR%\ITAsset4deloy.ps1"
exit
